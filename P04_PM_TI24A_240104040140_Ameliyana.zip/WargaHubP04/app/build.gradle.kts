plugins {
    alias(libs.plugins.android.application)
}

android {
    namespace = "id.antasari.p04.wargahub"
    compileSdk {
        version = release(37)
        compileSdk = 36
        buildFeatures { viewBinding = true }
        defaultConfig { minSdk = 26 }
    }
    dependencies {
        implementation("androidx.recyclerview:recyclerview:1.4.0")
        implementation("androidx.fragment:fragment-ktx:1.8.9")
        implementation("androidx.navigation:navigation-fragment-ktx:2.9.5")
        implementation("androidx.navigation:navigation-ui-ktx:2.9.5")
    }

    defaultConfig {
        applicationId = "id.antasari.p04.wargahub"
        minSdk = 26
        targetSdk = 37
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            optimization {
                enable = true
                packageScope = setOf("androidx.**", "kotlin.**", "kotlinx.**")
            }
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
}

dependencies {
    implementation(libs.androidx.activity.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.androidx.constraintlayout)
    implementation(libs.androidx.core.ktx)
    implementation(libs.material)
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.espresso.core)
    androidTestImplementation(libs.androidx.junit)
}